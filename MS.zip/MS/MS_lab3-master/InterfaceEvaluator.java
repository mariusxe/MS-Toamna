public interface InterfaceEvaluator {

    public double evaluate(int max);
}

