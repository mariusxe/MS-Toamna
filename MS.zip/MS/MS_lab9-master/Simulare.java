import java.util.Iterator;
import java.util.Map;

import static java.lang.Character.MAX_VALUE;

public class Simulare
{
    private static final int NR_CLIENTI_MAX = 100;
    private static final int NR_CLIENTI_MIN = 50;
    public static AgentiePostala PostaRomana;
    public static int clock;
    public static Client Clienti_temp[];
    private Write W;

    Simulare()
    {
        Read.console();
        W = new Write();
    }
    void start()
    {
        int int_temp;
        Generator G2,G_inexe;
        GenerareClient GC;
        Ghiseu Ghiseu_temp_value;
        int Ghiseu_temp_id;
       
        int_temp=G2.next()+NR_CLIENTI_MIN;
        Clienti_temp = new Client[int_temp];
        for(int i=0;i<Clienti_temp.length; i++){
            Clienti_temp[i]= GC.generare();
        }
        clock=0;
        W.console();
        


    }

}
