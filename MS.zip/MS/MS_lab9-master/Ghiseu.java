import java.util.Iterator;
import java.util.LinkedList;

import static java.lang.Character.MIN_VALUE;

public class Ghiseu
{
    private LinkedList<Client> coada_clienti;
    private Operatiune[] operatiuni;
    private int lungimemaxima, timpuldeutilizare, numarulmediuclienti;

    protected int Get_sizecoada_clienti()
    {
        return coada_clienti.size();
    }
    protected Iterator Get_coada_clienti()
    {
        return coada_clienti.iterator();
    }
    protected int Get_timpuldeutilizare()
    {
        return this.timpuldeutilizare;
    }
    protected int Get_lungimemaxima()
    {
        return this.lungimemaxima;
    }
    protected int Get_numarulmediuclienti()
    {
        return this.numarulmediuclienti;
    }
    protected void Push_coada_clienti(Client client)
    {
        coada_clienti.add(client);
        if(coada_clienti.size() > lungimemaxima){
            lungimemaxima = coada_clienti.size();
        }
    }
    protected void Pop_coada_clienti()
    {
        coada_clienti.remove();
    }
    protected void update()
    {
        if(coada_clienti.size()>0){
            timpuldeutilizare++;
            numarulmediuclienti = numarulmediuclienti + coada_clienti.size();
        }
    }
}
