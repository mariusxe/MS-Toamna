public interface Generator {
    public float next();
    public int seedvalue();
}
